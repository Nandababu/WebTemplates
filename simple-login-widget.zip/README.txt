A Pen created at CodePen.io. You can find this one at http://codepen.io/lexeckhart/pen/RPLPwX.

 This is a simple login widget with CSS3 animations and a simple jQuery validation. Feel free to reuse the components or the whole thing.