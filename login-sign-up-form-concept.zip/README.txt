A Pen created at CodePen.io. You can find this one at http://codepen.io/THEORLAN2/pen/MyedKo.

 Sign In & Sign Up Form concept , click on login and Sign Up to  changue and view the effect

- Update - Added background for text - ( Thanks  @JacobLucado)

https://twitter.com/thedany_Orlan2/status/708656737365012480