A Pen created at CodePen.io. You can find this one at http://codepen.io/R4ver/pen/lfFzI.

 Small concept of a YouTube login form in a flat design.