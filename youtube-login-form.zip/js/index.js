$("#loginClose").click(function () {
  $("#loginBox").fadeOut('fast');
});

$("#signIn").click(function () {
    $("#loginBox").fadeIn('fast');
});