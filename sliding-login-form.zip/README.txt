A Pen created at CodePen.io. You can find this one at http://codepen.io/humbl3man/pen/gfpjt.

 v1.2 - more fluid transitions. Instead of using css animations I am using jQuery to animate the form.