A Pen created at CodePen.io. You can find this one at http://codepen.io/jkaes/pen/asbJl.

 Forked to attempt a different kind of shadow. It doesn't look like the paper is floating off the surface, now.