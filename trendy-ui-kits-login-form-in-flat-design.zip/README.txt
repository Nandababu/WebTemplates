A Pen created at CodePen.io. You can find this one at http://codepen.io/metacaptin/pen/IHiEm.

 Inspired By http://blog.templatemonster.com/2013/08/12/free-psd-login-forms-flat-design/  
