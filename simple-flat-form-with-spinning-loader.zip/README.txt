A Pen created at CodePen.io. You can find this one at http://codepen.io/gwilakers/pen/xGwLyQ.

 This is a basic login form with various animations that happen on certain events. With a little added validation this form could be plugged into any site that needs logins.