A Pen created at CodePen.io. You can find this one at http://codepen.io/code_dependant/pen/Kkeyb.

 Experimenting with hidden login forms with animated reveals. This is the first of a few hopefully. 